# CMPSC470 - Assignment 1
Doug Fultz

## How To

### Requirements

1. Sun Lab machine

### How to: codegenerator.java

1. Compile java file

   `# javac codegenerator.java`

2. Execute codegenerator

   `# java codegenerator`

3. Show generated jasmin file

   `# cat simple.j`

4. Execute jasmin program

   `# java simple`
